--
-- PostgreSQL database dump
--

SET statement_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SET check_function_bodies = false;
SET client_min_messages = warning;

--
-- Name: plpgsql; Type: EXTENSION; Schema: -; Owner: 
--

CREATE EXTENSION IF NOT EXISTS plpgsql WITH SCHEMA pg_catalog;


--
-- Name: EXTENSION plpgsql; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION plpgsql IS 'PL/pgSQL procedural language';


SET search_path = public, pg_catalog;

SET default_tablespace = '';

SET default_with_oids = false;

--
-- Name: melt_bananas; Type: TABLE; Schema: public; Owner: api; Tablespace: 
--

CREATE TABLE melt_bananas (
    id integer NOT NULL,
    title text NOT NULL,
    lyrics text,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL
);


ALTER TABLE public.melt_bananas OWNER TO api;

--
-- Name: melt_bananas_id_seq; Type: SEQUENCE; Schema: public; Owner: api
--

CREATE SEQUENCE melt_bananas_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.melt_bananas_id_seq OWNER TO api;

--
-- Name: melt_bananas_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: api
--

ALTER SEQUENCE melt_bananas_id_seq OWNED BY melt_bananas.id;


--
-- Name: minutemen; Type: TABLE; Schema: public; Owner: api; Tablespace: 
--

CREATE TABLE minutemen (
    id integer NOT NULL,
    title text NOT NULL,
    lyrics text NOT NULL,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL
);


ALTER TABLE public.minutemen OWNER TO api;

--
-- Name: minutemen_id_seq; Type: SEQUENCE; Schema: public; Owner: api
--

CREATE SEQUENCE minutemen_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.minutemen_id_seq OWNER TO api;

--
-- Name: minutemen_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: api
--

ALTER SEQUENCE minutemen_id_seq OWNED BY minutemen.id;


--
-- Name: subdivisions; Type: TABLE; Schema: public; Owner: api; Tablespace: 
--

CREATE TABLE subdivisions (
    id integer NOT NULL,
    first_part character varying(255),
    second_part character varying(255),
    third_part character varying(255),
    image_path character varying(255),
    created_at timestamp without time zone,
    updated_at timestamp without time zone
);


ALTER TABLE public.subdivisions OWNER TO api;

--
-- Name: subdivisions_id_seq; Type: SEQUENCE; Schema: public; Owner: api
--

CREATE SEQUENCE subdivisions_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.subdivisions_id_seq OWNER TO api;

--
-- Name: subdivisions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: api
--

ALTER SEQUENCE subdivisions_id_seq OWNED BY subdivisions.id;


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: api
--

ALTER TABLE ONLY melt_bananas ALTER COLUMN id SET DEFAULT nextval('melt_bananas_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: api
--

ALTER TABLE ONLY minutemen ALTER COLUMN id SET DEFAULT nextval('minutemen_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: api
--

ALTER TABLE ONLY subdivisions ALTER COLUMN id SET DEFAULT nextval('subdivisions_id_seq'::regclass);


--
-- Data for Name: melt_bananas; Type: TABLE DATA; Schema: public; Owner: api
--

COPY melt_bananas (id, title, lyrics, created_at, updated_at) FROM stdin;
3	It's In The Pillcase	\N	2014-06-25 20:19:06.725964	2014-06-25 20:19:06.725964
4	Cactuses Come In Flocks	\N	2014-06-25 20:19:08.711528	2014-06-25 20:19:08.711528
5	Just Grub & Run	\N	2014-06-25 20:19:08.726909	2014-06-25 20:19:08.726909
6	Talk Like Pop	\N	2014-06-25 20:19:08.735398	2014-06-25 20:19:08.735398
7	Shining Hatcher	\N	2014-06-25 20:19:08.74298	2014-06-25 20:19:08.74298
8	F. Pt.1	\N	2014-06-25 20:19:08.750997	2014-06-25 20:19:08.750997
9	To The Core	\N	2014-06-25 20:19:08.759175	2014-06-25 20:19:08.759175
10	F. Pt.2	\N	2014-06-25 20:19:08.766556	2014-06-25 20:19:08.766556
11	Shuuuuuuuuuuuuuuuuu	\N	2014-06-25 20:19:08.774402	2014-06-25 20:19:08.774402
12	Bunny Wasted A Month Waiting	\N	2014-06-25 20:19:08.781577	2014-06-25 20:19:08.781577
13	Party-Hat	\N	2014-06-25 20:19:08.789596	2014-06-25 20:19:08.789596
14	Shouting About Love	\N	2014-06-25 20:19:08.800476	2014-06-25 20:19:08.800476
15	Sonic Turtle	\N	2014-06-25 20:19:08.810931	2014-06-25 20:19:08.810931
16	Bored Elephant	\N	2014-06-25 20:19:08.820644	2014-06-25 20:19:08.820644
17	Up And Down, 1, 2, 3...	\N	2014-06-25 20:19:08.828734	2014-06-25 20:19:08.828734
18	1 To 11	\N	2014-06-25 20:19:08.836406	2014-06-25 20:19:08.836406
19	Dried Up Water Park	\N	2014-06-25 20:19:08.844852	2014-06-25 20:19:08.844852
20	How To Say rip Them Off, Repeat After Me	\N	2014-06-25 20:19:08.865562	2014-06-25 20:19:08.865562
21	Interval.......	\N	2014-06-25 20:19:08.873212	2014-06-25 20:19:08.873212
22	Locoweed In The Bottle	\N	2014-06-25 20:19:08.881625	2014-06-25 20:19:08.881625
23	Ketchup-Mess	\N	2014-06-25 20:19:08.88981	2014-06-25 20:19:08.88981
24	We Love Choco-Pa!	\N	2014-06-25 20:19:08.897174	2014-06-25 20:19:08.897174
25	No Way To Hear	\N	2014-06-25 20:19:08.904236	2014-06-25 20:19:08.904236
26	We Had Tails In The Old Days	\N	2014-06-25 20:19:08.910739	2014-06-25 20:19:08.910739
27	So Far So Bad So What	\N	2014-06-25 20:19:08.917059	2014-06-25 20:19:08.917059
28	Frog Swins The River Down Giggling	\N	2014-06-25 20:19:08.924471	2014-06-25 20:19:08.924471
29	I Hate It! (Long Version)	\N	2014-06-25 20:19:08.931468	2014-06-25 20:19:08.931468
30	Who Cares	\N	2014-06-25 20:19:08.94008	2014-06-25 20:19:08.94008
31	Fmfyyd	\N	2014-06-25 20:19:08.952468	2014-06-25 20:19:08.952468
32	Pie War	\N	2014-06-25 20:19:08.975954	2014-06-25 20:19:08.975954
33	Ants Living In A Narrow Box	\N	2014-06-25 20:19:08.98346	2014-06-25 20:19:08.98346
34	Crayfish Song	\N	2014-06-25 20:19:08.990155	2014-06-25 20:19:08.990155
35	6 Feet Long For Her Neck	\N	2014-06-25 20:19:08.997625	2014-06-25 20:19:08.997625
36	Picnic With Panic (Long Version)	\N	2014-06-25 20:19:09.005021	2014-06-25 20:19:09.005021
37	Cell-Scape	\N	2014-06-25 20:19:09.013609	2014-06-25 20:19:09.013609
38	Phantasmagoria	\N	2014-06-25 20:19:09.022688	2014-06-25 20:19:09.022688
39	Shield Your Eyes, a Beast in the Well of Your Hand	\N	2014-06-25 20:19:09.031741	2014-06-25 20:19:09.031741
40	A Dreamer Who is Too Weak to Face Up	\N	2014-06-25 20:19:09.039841	2014-06-25 20:19:09.039841
41	Lost Parts Stinging Me So Cold	\N	2014-06-25 20:19:09.04883	2014-06-25 20:19:09.04883
42	Chain-Shot to Have Some Fun	\N	2014-06-25 20:19:09.057078	2014-06-25 20:19:09.057078
43	Like a White Bat in a Box, Dead Matters Go On	\N	2014-06-25 20:19:09.064416	2014-06-25 20:19:09.064416
44	Key is a Fact that a Cat Brings	\N	2014-06-25 20:19:09.071005	2014-06-25 20:19:09.071005
45	A Hunter in the Rain to Cut the Neck Up in the Present Stage	\N	2014-06-25 20:19:09.07775	2014-06-25 20:19:09.07775
46	If It is the Deep Sea, I Can See You There	\N	2014-06-25 20:19:09.084239	2014-06-25 20:19:09.084239
47	MxBx1998_13,000 Miles At Light Velocity	\N	2014-06-25 20:19:09.090386	2014-06-25 20:19:09.090386
48	Scratch Or Stitch	\N	2014-06-25 20:19:09.097512	2014-06-25 20:19:09.097512
49	RRaGG	\N	2014-06-25 20:19:09.104655	2014-06-25 20:19:09.104655
50	WEDGE	\N	2014-06-25 20:19:09.111727	2014-06-25 20:19:09.111727
51	Seesaw Semiology	\N	2014-06-25 20:19:09.119077	2014-06-25 20:19:09.119077
52	Circle-Jack (Chase The Magic Words, Lego Lego)	\N	2014-06-25 20:19:09.127244	2014-06-25 20:19:09.127244
53	Sick Zip Everywhere	\N	2014-06-25 20:19:09.133952	2014-06-25 20:19:09.133952
54	Disposable Weathercock	\N	2014-06-25 20:19:09.141825	2014-06-25 20:19:09.141825
55	Mind Thief	\N	2014-06-25 20:19:09.148417	2014-06-25 20:19:09.148417
56	Blandished Hatman	\N	2014-06-25 20:19:09.155045	2014-06-25 20:19:09.155045
57	Iguana In Trouble	\N	2014-06-25 20:19:09.162255	2014-06-25 20:19:09.162255
58	Tapirs Flown Away	\N	2014-06-25 20:19:09.16945	2014-06-25 20:19:09.16945
59	His Name Is Mickey (At Last She Got Him)	\N	2014-06-25 20:19:09.177015	2014-06-25 20:19:09.177015
60	We Love Choco-Pa !	\N	2014-06-25 20:19:09.184757	2014-06-25 20:19:09.184757
61	Some Kind Of ID	\N	2014-06-25 20:19:09.191875	2014-06-25 20:19:09.191875
62	Stick Out	\N	2014-06-25 20:19:09.198858	2014-06-25 20:19:09.198858
63	Scrubber	\N	2014-06-25 20:19:09.205772	2014-06-25 20:19:09.205772
64	Screw, Loose	\N	2014-06-25 20:19:09.213119	2014-06-25 20:19:09.213119
65	First Defy	\N	2014-06-25 20:19:09.223031	2014-06-25 20:19:09.223031
66	So Unfilial Rule	\N	2014-06-25 20:19:09.229859	2014-06-25 20:19:09.229859
67	Spathic !	\N	2014-06-25 20:19:09.236692	2014-06-25 20:19:09.236692
68	Picnic In Panic	\N	2014-06-25 20:19:09.243662	2014-06-25 20:19:09.243662
69	It's In The Pillcase	\N	2014-06-25 20:19:09.25015	2014-06-25 20:19:09.25015
70	Surfin' USA	\N	2014-06-25 20:19:09.257322	2014-06-25 20:19:09.257322
71	Bad Gut Missed Fist	\N	2014-06-25 20:19:09.267083	2014-06-25 20:19:09.267083
72	Ketchup-Mess	\N	2014-06-25 20:19:09.27809	2014-06-25 20:19:09.27809
73	Plot In A Pot	\N	2014-06-25 20:19:09.286234	2014-06-25 20:19:09.286234
74	Scratch Or Stitch	\N	2014-06-25 20:19:09.295456	2014-06-25 20:19:09.295456
75	Plot In A Pot	\N	2014-06-25 20:19:09.304626	2014-06-25 20:19:09.304626
76	Sick ZiP Everywhere	\N	2014-06-25 20:19:09.311522	2014-06-25 20:19:09.311522
77	DisPosable Weathercock	\N	2014-06-25 20:19:09.319076	2014-06-25 20:19:09.319076
78	Ten Dollars A Pile	\N	2014-06-25 20:19:09.326219	2014-06-25 20:19:09.326219
79	Ketchup- Mess	\N	2014-06-25 20:19:09.333372	2014-06-25 20:19:09.333372
80	BuZZer #P	\N	2014-06-25 20:19:09.341602	2014-06-25 20:19:09.341602
81	Rough Dogs Have Bumps	\N	2014-06-25 20:19:09.350963	2014-06-25 20:19:09.350963
82	IGUANA In Trouble	\N	2014-06-25 20:19:09.390088	2014-06-25 20:19:09.390088
83	It's In The Pillcase	\N	2014-06-25 20:19:09.397425	2014-06-25 20:19:09.397425
84	Test_ Ground 1	\N	2014-06-25 20:19:09.403364	2014-06-25 20:19:09.403364
85	Zoo, No Vacancy	\N	2014-06-25 20:19:09.409545	2014-06-25 20:19:09.409545
86	A Finger To Hackle	\N	2014-06-25 20:19:09.415799	2014-06-25 20:19:09.415799
87	TYPe B For Me	\N	2014-06-25 20:19:09.42274	2014-06-25 20:19:09.42274
88	His Name Is Mickey (at last she got him...)	\N	2014-06-25 20:19:09.42863	2014-06-25 20:19:09.42863
89	Back To The WomB	\N	2014-06-25 20:19:09.43429	2014-06-25 20:19:09.43429
90	I HATe It!	\N	2014-06-25 20:19:09.440931	2014-06-25 20:19:09.440931
91	What Do You Slaughter Next?	\N	2014-06-25 20:19:09.446915	2014-06-25 20:19:09.446915
92	EYE- Q Trader	\N	2014-06-25 20:19:09.453019	2014-06-25 20:19:09.453019
93	DIG Out!	\N	2014-06-25 20:19:09.458961	2014-06-25 20:19:09.458961
94	Contortion Out Of Confusion	\N	2014-06-25 20:19:09.465671	2014-06-25 20:19:09.465671
95	Pigeons On My EYes (GO TO Bed!!!)	\N	2014-06-25 20:19:09.471387	2014-06-25 20:19:09.471387
96	Teeny Shiny	\N	2014-06-25 20:19:09.477121	2014-06-25 20:19:09.477121
97	Free The Bee	\N	2014-06-25 20:19:09.484453	2014-06-25 20:19:09.484453
98	Flash Cube, Or Eyeball	\N	2014-06-25 20:19:09.49048	2014-06-25 20:19:09.49048
99	Lost In Mirror	\N	2014-06-25 20:19:09.496509	2014-06-25 20:19:09.496509
100	First Contact To Planet Q	\N	2014-06-25 20:19:09.502577	2014-06-25 20:19:09.502577
101	Warp, Back Spin	\N	2014-06-25 20:19:09.508478	2014-06-25 20:19:09.508478
102	Third Attack	\N	2014-06-25 20:19:09.514613	2014-06-25 20:19:09.514613
103	Cub, Not Cube	\N	2014-06-25 20:19:09.520741	2014-06-25 20:19:09.520741
104	Flip And Hit	\N	2014-06-25 20:19:09.526747	2014-06-25 20:19:09.526747
105	Bright Splat (Red Point, Black Dot)	\N	2014-06-25 20:19:09.533197	2014-06-25 20:19:09.533197
106	Skit Closed, Windy... 1	\N	2014-06-25 20:19:09.539922	2014-06-25 20:19:09.539922
\.


--
-- Name: melt_bananas_id_seq; Type: SEQUENCE SET; Schema: public; Owner: api
--

SELECT pg_catalog.setval('melt_bananas_id_seq', 106, true);


--
-- Data for Name: minutemen; Type: TABLE DATA; Schema: public; Owner: api
--

COPY minutemen (id, title, lyrics, created_at, updated_at) FROM stdin;
64	Search\n	Son of a mother\nSon of a father\nYou can look inside you\nYou can look inside me\nCome on and search!\nSearch deep inside\nYou can put it together\nYou can pull it apart\nYou relapse unconscious\nYou don't remember!\n	2014-06-29 02:19:04.237324	2014-06-29 02:19:04.237324
65	Tension\n	When you're revealing I get that feeling\nOf a blind man in bed\nCouldn't hear what I said\nNo way\nWhen you're revealing\nI get that feeling\nOf a monk in a church\nA big empty church\n	2014-06-29 02:19:04.24961	2014-06-29 02:19:04.24961
66	Ruins\n	Culture moves the hands\nOf the man yet scanned\nWhose judgment?\nThe matter was life\nWho got the hand shake?\nThe ruins of a culture still maimed\nRemember the camps before you were born\nThe mourn of the families\nCulture moves the hands\nOf the man yet scanned\n	2014-06-29 02:19:04.251643	2014-06-29 02:19:04.251643
67	The Punch Line\n	I believe when they found the body of General George A. Custer\nQuilled like a porcupine with Indian arrows\nHe didn't die with any honor, any dignity, or any valor\nI believe when they found George A. Custer\nAn American general, patriot, and Indian-fighter\nHe died with shit in his pants!\n	2014-06-29 02:19:04.25321	2014-06-29 02:19:04.25321
68	History Lesson\n	A hundred thousand years ago before legends were ever told\nHomo Sapiens stood erect, mind empty and mind fresh\nCreated love and hate\nThen God and Anti-God\nHuman slaughtered\nHuman\nFirst with stone\nThen with metal\nNow with heat\nIt was all for power\n	2014-06-29 02:19:04.254603	2014-06-29 02:19:04.254603
69	Fanatics\n	There's a hanging in Turkey.\nTwo necks in a noose\nOne's a rightist\nThe other's a leftist.\nWhat the fuck?\nFanatics!\n	2014-06-29 02:19:04.255972	2014-06-29 02:19:04.255972
70	Gravity\n	Against The flux\nPlay the field; push the wheel\nHorizontal\nSilently talkin'\nBeing boxed in by friends friends friends of friends and so on\nFruitless triumph Newton's search only proves that flesh and muscle are being pulled off our bones\n	2014-06-29 02:19:04.257219	2014-06-29 02:19:04.257219
71	Bob Dylan Wrote Propaganda Songs\n	I'm waiting\nAnd diversing\nI'm collecting\nDispersing\nInformation\nLiberation\nBob Dylan wrote propaganda songs!\nManifesto\nOn my window\nAnd my fruit\nRotation\nAdmiration\nOutline my root\nBob Dylan wrote propaganda songs!\n	2014-06-29 02:19:04.258459	2014-06-29 02:19:04.258459
72	The Anchor\n	Made a dream last night\nWish I hadn't awoken\nWind blew warm in my face\nNaked in an Epsom\nFive beautiful girls around me\nI was so damn bad\nI took them on one at a time\nWake up, heart yanked out\nAnchor dragging behind\n	2014-06-29 02:19:04.259736	2014-06-29 02:19:04.259736
73	Self-Referenced\n	Burned-out wreck spotted on the beach: a symbol of my life\nHow can I believe in books when my heart lies to me?\nI'm full of shit!\nBumming real hard on cold steel facts - I'm full of shit!\n	2014-06-29 02:19:04.261061	2014-06-29 02:19:04.261061
74	The Toe Jam\n	Instrumental\n	2014-06-29 02:19:04.262476	2014-06-29 02:19:04.262476
75	Little Man With A Gun In His Hand\n	The highest love, a woman's touch\nHarmony, a strong mind, a strong body, beauty\nAll the things He couldn't be\nAll The things he couldn't have\nLittle man with a gun in his hand\n	2014-06-29 02:19:04.263809	2014-06-29 02:19:04.263809
76	Shit You Hear At Parties\n	Sometimes the news is like a loud hum in my amplifier\nIt rings my head out like a filthy washcloth\nWith little folds; thousands of little folds!\nThe shit you hear at parties\nKick in the idiot box\nWait for the news in the history books\nLike junkies who hate their heroin\n	2014-06-29 02:19:04.265168	2014-06-29 02:19:04.265168
77	Party With Me Punker\n	Party with me, punker!\nParty with me, punker!\nIn a condo\nIn an air raid shelter\nIn a photo booth\nThe fascist pogo\nParty with me, punker!\nParty with me, punker!\nWith napalm\nWith marijuana\nWith a clenched fist\nWith the history of the world\nParty with me, punker!\n	2014-06-29 02:19:04.266441	2014-06-29 02:19:04.266441
78	Anxious Mo-Fo\n	Serious as a heart attack!\nMakes me feel this way\nNo device to measure, no word can define\nI mean what I’m trying to say is\nHow can I express – let alone possess?\nSerious as a heart attack!\nMakes me feel this way\n	2014-06-29 02:19:04.267681	2014-06-29 02:19:04.267681
79	Viet Nam\n	Let’s say I got a number\nThat number’s fifty thousand\nThat’s ten percent of five hundred thousand\nOh, here we are in French Indochina!\nExecutive order, congressional decision\nThe working masses are manipulated\nWas this our policy?\nTen long years\nNot one domino shall fall\n	2014-06-29 02:19:04.268852	2014-06-29 02:19:04.268852
80	It's Expected I'm Gone\n	I don't want to hurt\nSee, my position was here\nI mean, as it was, I was\nSo this led to the downfall of man\nI can make seconds feel hours\nI make certain that my head is connected to my body\nNo hope?\nSee, that's what gives me guts\nBig fucking shit!\nRight now, man\n	2014-06-29 02:19:04.269838	2014-06-29 02:19:04.269838
81	Two Beads At The End\n	Caught by a camera taken at shutter speed\nMy neck's in a knot, two beads at the end\nBolt cutters close, my head rolls again\nTrapped in your snare, voices fly at me\nSnap like a tiger, strikes like a snake\nFeel like a poker in someone's fireplace\n	2014-06-29 02:19:04.270974	2014-06-29 02:19:04.270974
82	Do You Want New Wave Or Do You Want The Truth?\n	A word war will set off the keg\nMy words are war\nShould a word have two meanings?\nWhat the fuck for?\nShould words serve the truth?\nI stand for language\nI speak the truth\nI shout for history\nI am the cesspool\nFor all the shit to run down in\n	2014-06-29 02:19:04.272002	2014-06-29 02:19:04.272002
83	Shit From an Old Notebook\n	Let the products sell themselves!\nFuck advertising, commercial psychology\nPsychological methods to sell should be destroyed\nBecause of their own blind involvement in their own conditioned minds\nThe unit bonded together\nMorals, ideals, awareness, progress\nLet yourself be heard!\n	2014-06-29 02:19:04.273051	2014-06-29 02:19:04.273051
84	Nature Without Man\n	The boundary, the border of right and wrong\nThe tariff is self, the freedom of feeling the criminal\nThe pied piper, the heart and mind\nNature without man\n	2014-06-29 02:19:04.274109	2014-06-29 02:19:04.274109
85	One Reporter's Opinion\n	What can be romantic to Mike Watt?\nHe’s only a skeleton\nHis body is a series of points with no height, length, or width\nIn his joints, he feels life\nHis strongest connection\nBetween the yelling and the sleep\nPain is the toughest riddle\nHe’s chalk!\nHe’s a dartboard!\nHis sex is disease!\nHe’s a stop sign!\n	2014-06-29 02:19:04.275155	2014-06-29 02:19:04.275155
86	Maybe Partying Will Help\n	As I look over this beautiful land\nI can't help but realize that I am alone\nWhy am I able to waste my energy\nto notice life being so beautiful?\nMaybe partying will help\nAnd what of the people who don't have what I ain't got?\nAre they victims of my leisure?\nTo fail is to be a victim\nTo be a victim of my choice\nMaybe partying will help\n	2014-06-29 02:19:04.276134	2014-06-29 02:19:04.276134
87	Toadies\n	No. 7 on the chump list\nPlaying stooge, eatin' shit\nUsing that as a reason\nFor kickin' shit on the dumb fucks\nWe are cuss-words, nearly illiterate\nDedicated to fightin' toadies\n	2014-06-29 02:19:04.277175	2014-06-29 02:19:04.277175
88	Retreat\n	Real things conditioning will lose their meaning\nThe toilet starts flushing; sets me off again\nBut I am a thorn, I read it in your face\nThe cough's a thunderclap, my head's a tape recorder\n	2014-06-29 02:19:04.278334	2014-06-29 02:19:04.278334
89	The Big Foist\n	A richer understanding of what's already understood\nNo meanings from the here and now\nWhat gift could be a work of art?\nCan you call it the big foist?\nI'm fuckin' overwhelmed!\n	2014-06-29 02:19:04.2795	2014-06-29 02:19:04.2795
90	Corona\n	The people will survive in their environment\nThe dirt, scarcity and the emptiness of our South\nThe injustice of our greed, the practice we inherit\nThe dirt, scarcity and the emptiness of our South\nThere on the beach, I could see it in her eyes\nI only had a Corona, five-cent deposit\n	2014-06-29 02:19:04.28053	2014-06-29 02:19:04.28053
91	The Glory Of Man\n	Starting with the affirmation of man\nI work myself backwards using cynicism\n(the time monitor, the space measurer)\nI live sweat but I dream light years\nI am the tide - the rise and the fall\nThe reality soldier, the laugh child\nThe one of the many, the flame child\n(the time monitor, the space measurer)\n	2014-06-29 02:19:04.281543	2014-06-29 02:19:04.281543
92	Take 5, D.\n	Hope we can rely on you not to use shower. You're not keeping tub caulked. Caused both downstairs bath ceilings and walls to be soggy. Tub has to properly caulked prior to any shower. Walls are drenched -- I'll refer plumber here. Had to pay for two service calls. Water drips from all around. Kathy's ceiling, my ceiling. Don't use shower. Don't use shower.\n	2014-06-29 02:19:04.282685	2014-06-29 02:19:04.282685
93	My Heart And The Real World\n	And so my soul collapsed into a big guilt wad\nSome big thunder law forces me to eat shit\nAnd if I was a word could my letters number a hundred?\nMore likely coarse and guttural one syllable Anglo-Saxon\nI'm a victim of fact let's say I loved a girl\nBut the world was wrong and I was forced to march in line\nBut it felt like handcuffs\nMachines disregard my pronouns\nI am defeated, I'm a cool damp clay\n	2014-06-29 02:19:04.283664	2014-06-29 02:19:04.283664
94	History Lesson Part II\n	Our band could be your life\nReal names'd be proof\nMe and Mike Watt, we played for years\nPunk rock changed our lives\nWe learned punk rock in Hollywood\nDrove up from Pedro\nWe were fucking corndogs\nWe'd go drink and pogo\nMr. Narrator, this is Bob Dylan to me\nMy story could be his songs; I'm his soldier child\nOur band is scientist rock\nBut I was E. Bloom, Richard Hell, Joe Strummer and John Doe\nMe and Mike Watt, playing guitar\n	2014-06-29 02:19:04.284627	2014-06-29 02:19:04.284627
95	The Roar Of The Masses Could Be Farts\n	Soft and understanding eyes of the young\nMoving with abandon atop the green lawns\nMalleable as luck allows faking all the ties\nForced out in time\nThese expressions met\nImprovised inventions lost in the way\nAbsolute the course which instinct betrays\nGrinding in reversal\nOutdo til done\nProper naked self\nSolutions surround\nIn brightness be it real\nBlinded and free\nPastel gems hit\nPearlesque in flaw\nSpark of the instant\nChallenging the time\nView the observer's plagiarizing hands\n	2014-06-29 02:19:04.285644	2014-06-29 02:19:04.285644
96	Mr. Robot's Holy Orders\n	Force fed\nSifted\nTin can\nPull handle\nPuppet\nPull toys\n	2014-06-29 02:19:04.286619	2014-06-29 02:19:04.286619
97	Themselves\n	All these men who work the land\nShould evaluate themselves and make a stand\nCan't they see beyond the rhetoric?\nThe lies and promises that don't mean shit\nAnd all the men who learned to hate them\n	2014-06-29 02:19:04.287637	2014-06-29 02:19:04.287637
98	Please Don't Be Gentle With Me\n	Just wake up And tug my hair\nAnd let me know\nAll of the outside world and you are there\nAnd never be too gentle with me\n	2014-06-29 02:19:04.288605	2014-06-29 02:19:04.288605
99	Nothing Indeed\n	The interruption went\nSmall snag in life\nPothole in the road\nIt's only a detour\nA minor deterrent\nThat can't unload\nMy examination Parts a to b\nThere is no cause\nNo cause at all\nFor my hesitation\nNothing indeed\n	2014-06-29 02:19:04.289576	2014-06-29 02:19:04.289576
100	This Ain't No Picnic\n	Working on the edge\nLosing my self-respect\nFor a man who presides over me\nThe principles of his creed\nPunch in, punch out\nEight hours, five days\nSweat, pain and agony\nOn Friday I'll get paid\nThis ain't no picnic\nHey mister don't look down on me\nFor what I believe\nI got my bills and the rent\nI should be content\nBut our land isn't free\nSo I'll work my youth away\nIn the place of a machine\nI refuse to be a slave\nThis ain't no picnic\n	2014-06-29 02:19:04.290591	2014-06-29 02:19:04.290591
101	Spillage\n	A clear and dusty day in June\nMy stoned mind just spilled that line\nDescribing, what's it like, describing?\nBelieving that the sum is "yes"\nLooking around at all my comrades\nMy police state mind just spilled that line\nI want to give names to our bonds\nI need names to play the game\nBut what makes my heart run?\nWhy the thunder in my thighs?\nMy body, my mind\nThe idea of my life seems like a symbol\n	2014-06-29 02:19:04.291606	2014-06-29 02:19:04.291606
102	Untitled Song For Latin America\n	The western hemisphere and all inside\nWe know who's murdering the innocent\nThey are children playing with guns\nThey are children playing with countries\nMining harbors, creating contras\nThe games they play, the lives they take\nThey bank their money in this country\nThey steal from the innocent\nA colonial trait that's much too old\nThe banks, the lives, the profits, the lies\nI would call it genocide\nAny other word would be a lie\n	2014-06-29 02:19:04.292559	2014-06-29 02:19:04.292559
103	Jesus And Tequila\n	I had a girl\nShe loved what she saw\nShe loved me so good\nShe made her daddy mad\nMy woman cried\nShe's dead to me now\nMy woman ran off\nAnd I can't deny it\nMy life - Jesus and tequila\nI'm satisfied\nAnd I can't deny it\nI had a job\nIt paid me good\nI could have my phone\nAnd tip the preacher too\nMy boss yelled\nHe's dead to me now\nMy boss kicked me out\nAnd I can't deny it\nMy life - Jesus and tequila\nI'm satisfied\nAnd I can't deny it\nYou better listen to me\n'Cause I'm gonna tell you, son\nDon't give away your love\nAnd don't give away your sweat\nBecause a girl can't know you\nAnd a boss can't afford you\nRemember Jesus and tequila\nI'm satisfied\nAnd I can't deny it\n	2014-06-29 02:19:04.293571	2014-06-29 02:19:04.293571
104	Storm In My House\n	If I could, I surely would\nGive my life to you\nSo you can have two\nTake me in your arms and lie to me\nYou tell me it's always going\nTo be like this\nThe world is the coldest place\nSurely the coldest place.\nThere's a storm inside my house\nRaging and relentless\nWind tearing at the rafters\nHowling through the timbers\nHard stinging rain\nFalling in and falling down\nHope this storm doesn't rip my roof off\nMy skin keeps the storm inside\n	2014-06-29 02:19:04.294547	2014-06-29 02:19:04.294547
105	Martin's Story\n	What you makin', man?\nTakes time\nA little bit\nA little bit more\nThe effort's worth it\nFeels good\nDesigned by me\nTry and try\nThat's the way you want it\nIf you know\nThat ain't the way it always goes\nA little bit\nA little bit more\nWhat you makin', man?\nTakes time\n	2014-06-29 02:19:04.295542	2014-06-29 02:19:04.295542
106	Little Man With A Gun In His Hand\n	The highest love, a woman's touch\nStrong mind, strong body\nAll the things he couldn't be\nAll the things he couldn't have\nLittle man with a gun in his hand\n	2014-06-29 02:19:04.29647	2014-06-29 02:19:04.29647
107	The World According To Nouns\n	The state, the church, the plans\nThe waste, the dead, the mine, the cut\nWhat's the verb behind it all?\nThe who, the how, the why, the where, the when, the what\nCan these words refine that truth?\n	2014-06-29 02:19:04.297913	2014-06-29 02:19:04.297913
108	The Price Of Paradise\n	How I remember the history I have seen\nI was just a young boy, the horror I couldnt forsee\nAll the pain that comes with war\nAll the scars that never heal\nHere in paradise the price is cheap\nYoung men die for greed\nAcross the ocean in a land they call Vietnam\nYoung men dying is all it would cost\nWe were told and proudly believed\nThey would fight to keep us free\nHere in America the price is cheap\nYoung men die for what?\nMy brother, the soldier was a hero who survived\nHe'd tell the stories of men who died without dreams\nAnd they fight for men twice their age\nThe smell of death made his life change\nThe price of paradise is stained with blood\nWhy? All pawns and puppets of flesh and bone\nWill die for their leaders far from their homes\nThese are men who died very young\nAfraid to see that their cause was unjust\nWhy couldnt they live for life?\nNot die to survive\n	2014-06-29 02:19:04.299318	2014-06-29 02:19:04.299318
109	The Big Stick\n	Now over there in Managua Square\nWith American made bombs falling everywhere\nThey kill women and children and animals too\nThese bombs are made by people like me and you\nAnd we're told that we hold a big stick over them\nBut I know from what I've read that peace is in our hands\nNow over there in Guatamala my friend\nWe're making mistakes there once again\nUncle Sam supports a fascist regime\nThat doesnt represent the people over there\nWe learn and believe there is justice for us all\nAnd we lie to ourselves with a big stick up our ass\nNow if we stand and yell it out\nThat war isn't what we're all about\nThen someone will come and bring us back\nTo get the peace train back on its tracks\nThis is what I'm singing about\nThe race war that America supports\nIndians will never die\nThey'll do just fine if we let them try\nThough we hold, we're never told that peace is in our hands\nIf we stop there is time to heal the scars we've caused\nTo heal the scars we've caused\n	2014-06-29 02:19:04.30046	2014-06-29 02:19:04.30046
110	Political Nightmare\n	Someone's doing something\nConfusion\nAnother invasion?\nSympathize with who?\nSomeone killed somebody\nConfusion\nDid anyone gain?\nHow much did it cost?\nWoke up screaming\nSomeone changed sides\nEveryone was dying\nOne too many votes\nSatan won\n	2014-06-29 02:19:04.301617	2014-06-29 02:19:04.301617
111	Courage\n	Where's your courage? Are you afraid to die?\nAre you happy that God is on your side?\nI wrote this song in a story of men who died for glory\nWhere's your courage?\nDo you think you're alone?\nAre you laughing for being blind and pure?\nI wrote this song in a story of men who died for glory\nWhere's your courage?\nDo you share all you have?\nAre you hiding from something you dont know?\nWhere's your courage?\n	2014-06-29 02:19:04.302919	2014-06-29 02:19:04.302919
113	Spoken Word Piece\n	Liberal Man meets Conservative Man\nConservative Man wears his myth on his skin\nLiberal Man has to explain his and keeps his shirt all buttoned up\nConservative Man greets Liberal Man with a well-rehearsed cold stare\nLiberal Man replies by issuing forth horseshit\nConservative Man retaliates by taking the concrete reality of the Situation and lodging it, like a wedge, right between both sides of Liberal Man's brain\nLiberal Man is caught off guard by this apparent non-abstraction\nThere is one full minute of confusion\nLiberal Man becomes Conservative Man\nConservative Man becomes Liberal Man\nWar is declared\nLiberal Man cheats by calling in reinforcements\nConservative Man is set upon by a mob and murdered\nSaid mob then turns on Liberal Man and he dies a broken man\n	2014-06-29 02:19:04.305692	2014-06-29 02:19:04.305692
114	Stories\n	I heard one today about the one I love\nI heard one earlier that shook me up\nI heard one the other day, can't believe it's true\nI heard one by accident wish I had it\nI heard one so many times\nI couldn't care any more\n	2014-06-29 02:19:04.307057	2014-06-29 02:19:04.307057
115	What Is It?\n	In your eyes I've seen it\nIn my silence it's heard\nIn a dream it lingers\nIn solitude it's known\nIn honesty I scream it\nIn panic I forget it\nIn desperation I need it\nIn time I lose it\nIn my mind I save it\n	2014-06-29 02:19:04.308515	2014-06-29 02:19:04.308515
116	Just Another Soldier\n	Over 300 dead, we still got pride\nWe've lost all our morals, we still got pride\nShould we fight this war in some far corner of the globe\nAnd learn how to die for some unjust cause\nIs this our future?\nAshes are all that remain\nIt's easy when you got pride\nHow much pride does a dead soldier got?\nHis life so short, no chance to even start\nThe ones he left behind\nThe world he'll never see\nBut no one could deny that the soldier died with pride\n	2014-06-29 02:19:04.309895	2014-06-29 02:19:04.309895
117	Situations At Hand\n	There are still lofty dreams meager desires and still silliness\n	2014-06-29 02:19:04.311198	2014-06-29 02:19:04.311198
118	Political Song For Michael Jackson To Sing\n	List monitors arrive with petition\nIron-fisted philosophy\nIs your life worth a painting?\nIs this 'girl vs. boy' with different symbols?\nBeing born is power!\nScout leader Nazi tagged as 'big sin'\nYour risk chains me hostage\nMe, I'm fighting with my head, I am not ambiguous\nI must look like a dork!\nMe, naked with textbook poems spout fountain against the Nazis\nWith weird kinds of sex symbols in speeches that are big dance thumps\nIf we heard mortar shells, we'd cuss more in our songs\nAnd cut down the guitar solos\nSo dig this big crux:\nOrganizing the boy scouts for murder is wrong\nTen years beyond the big sweat point\nMan, it was still there, ever without you\nComing back around, look!\nComing together, for just a second, a peek, a guess\nAt the wholeness that's way too big\n	2014-06-29 02:19:04.31262	2014-06-29 02:19:04.31262
119	I Felt Like A Gringo\n	A ton of white boy guilt, that's my problem\nObstacle to joy (one reason for drugs)\nSlept on a Mexican beach, slept in trash\n(American trash) thinking too much can ruin a good time\nI asked a Mexican who ran a bar for Americans: "who won" I said, "the election?"\nHe laughed and I felt like a gringo\nWe paid for a song and they had fun with us\nWhy can't you buy a good time?\nWhy are there soldiers in the streets?\nWhy did I spend the fourth in someone else's country?\n	2014-06-29 02:19:04.313665	2014-06-29 02:19:04.313665
120	Jesus And Tequila\n	I had a girl, she loved what she saw\nShe loved me so good, she made her daddy mad\nMy woman cried; she's dead to me now\nMy woman ran off, and I can't deny it\nMy life: Jesus and tequila\nI'm satisfied, and I can't deny it\nI had a job; it paid me good\nI could have my fun and tip the preacher too\nMy boss yelled; he's dead to me now\nMy boss kicked me out, and I can't deny it\nMy life: Jesus and tequila\nI'm satisfied, and I can't deny it\nYou better listen to me 'cause I'm gonna tell you, son\nDon't give away your love and don't give away your sweat\nBecause a girl can't know you, and a boss can't afford you\nRemember Jesus and tequila\nI'm satisfied and I can't deny it\n	2014-06-29 02:19:04.314617	2014-06-29 02:19:04.314617
121	King Of The Hill\n	What is peace to the people who work the land and die in wars?\nIt was learned in a game that was played by us all\nWho held the top of the hill?\nFrom the rest was called the king\nAnd I can't believe it all was good for humankind\nIs it peace to point the guns?\nIs it war To fire the guns?\nWe would run with all of our might, push the king off to take the hill\nAnd to learn who was king and who makes the better serf\nI can't believe it all was good for humankind\n	2014-06-29 02:19:04.315593	2014-06-29 02:19:04.315593
122	Cut\n	Hey, ice machine will you cut me?\nThin line... Cut!\nBig scissors!\nCut loose!\nBend!\nTense!\nBig scissors!\nStop!\nCut!\n	2014-06-29 02:19:04.316612	2014-06-29 02:19:04.316612
123	Tour-Spiel\n	Born in the shed with the guitar on\nWe jammed the schtik to do for gigs.\nWith bits and pieces Of a working thesis\nWe jammed the schtik to do for gigs\nNow when we took me and D. Boon and George's stench\nAnd put them up on stage.\nWe'd fight at practice then jam econo\nAnd spout the tour-spiel\nI dreamed I was E Bloom But I woke up Joe Bouchard\nIn some town out on the road\nWith patent-leather boots on\nJust like richard told me\nAnother hack on the Spectors tour\nNow you got your guitar and your practice amp\nYou travel the USA in a van\nAnd Troccoli's counting on some situation\nAre you going to write the song I demand?\nAnd with the guitar turned off\nAnd the gas tank empty\nAnd the typewriter on\nBut my head is empty\nAnd to really find me I've got to look inside me\nAnd cut the tour-spiel\n	2014-06-29 02:19:04.317685	2014-06-29 02:19:04.317685
124	Take Our Test\n	Say now My trip in line with others\nHave the door pointing to others\nDoor means a separate wall is in between\nSymbols assert the Big Butt Whoopin\nClose your eyes, open them\nTake our test!\nClose your eyes, open them\nNot since those days\nThis rhythm that is all head\nWhat makes Breaks the fakes\nClose your eyes, open them\nTake our test!\nClose your eyes, open them\nNot since those days\nAnd when reality appears digital\nAnd the big hankering cometh\nI'll vote yes for life in the big choice poll\nI'll be glad I did\nYour mind Organized by Nazis\nYour heart and mind conspiring\nClose your eyes, open them\nTake our test!\nClose your eyes, open them\nNot since those days\nForever with you\nEver without you\nTake our test!\n	2014-06-29 02:19:04.318763	2014-06-29 02:19:04.318763
125	Joe McCarthy's Ghost\n	Can you really be sure of the goddamn time of day?\nCan you take the dirt from the fist of a foreigner?\nAre you going to fight when they call out your number?\nCan you toe the line?\nCan you repeat what you've been told?\nCan you bite the bullet?\nCan you see the enemy?\nCan you point the finger?\nCan you prove your loyalty?\nJoe McCarthy!\n	2014-06-29 02:19:04.31981	2014-06-29 02:19:04.31981
126	Anxious Mo-Fo\n	Serious as a heart attack!\nMakes me feel this way\nNo device to measure\nNo word can define\nI mean what I'm trying to say is\nHow can I express? (let alone possess)\nSerious as a heart attack!\nMakes me feel this way	2014-06-29 02:19:04.320813	2014-06-29 02:19:04.320813
112	The Red And The Black\n	Canadian mounted, baby\nA police force that works\nRed and black is their color scheme\nGet their man in the end\nIt's all right... It's all right\nYou kill, you maim\nYou kill, you maim\nFrontenac chateau, baby\nI cross the frontier at ten\nGot a whip in my hand, baby\nAnd a girl or a huskie at leather's end\nIt's all right... It's all right\nYou kill, you maim\nYou kill, you maim\nHornswoop me bungo pony\nDog sled on ice\nMake a dash for freedom, baby\nDont skate on polar ice\nIt's too thick to be sliced by the light\nOf long,white polar nights\nIt's all right... It's all right\nYou kill, you maim\nYou kill, you maim\n(Originally by Blue Oyster Cult)\n	2014-06-29 02:19:04.304247	2014-06-29 02:19:04.304247
\.


--
-- Name: minutemen_id_seq; Type: SEQUENCE SET; Schema: public; Owner: api
--

SELECT pg_catalog.setval('minutemen_id_seq', 126, true);


--
-- Data for Name: subdivisions; Type: TABLE DATA; Schema: public; Owner: api
--

COPY subdivisions (id, first_part, second_part, third_part, image_path, created_at, updated_at) FROM stdin;
1	Sundance	Terrace	Estates	sd1.jpg\n	2011-04-05 15:53:13.883336	2011-04-05 15:53:13.883336
2	Sunset	Village	at RidgeGate	sd2.jpg\n	2011-04-05 15:53:13.967101	2011-04-05 15:53:13.967101
3	Elk	Estates	at The Greens	sd3.jpg\n	2011-04-05 15:53:13.97063	2011-04-05 15:53:13.97063
4	Wolf	Glen	at Wolf Hollow	sd4.jpg\n	2011-04-05 15:53:13.974645	2011-04-05 15:53:13.974645
5	Marmot	Preserve	at Fox Hollow	sd5.jpg\n	2011-04-05 15:53:13.978143	2011-04-05 15:53:13.978143
6	Willow	Woods		sd6.jpg\n	2011-04-05 15:53:13.981485	2011-04-05 15:53:13.981485
7	Sandstone	Promenade		sd7.jpg\n	2011-04-05 15:53:13.985604	2011-04-05 15:53:13.985604
8	Orchard	Prairie	at Pine Acres	sd8.jpg\n	2011-04-05 15:53:13.989069	2011-04-05 15:53:13.989069
9	Aspen	Reserve		sd1.jpg\n	2011-04-05 15:53:13.992403	2011-04-05 15:53:13.992403
10	Tamarac	Park		sd2.jpg\n	2011-04-05 15:53:13.996458	2011-04-05 15:53:13.996458
16	Summit	Creek		sd8.jpg\n	2011-04-05 15:53:14.017017	2011-04-05 15:53:14.017017
17	Chardonnay	Homestead	at SkyRidge	sd1.jpg\n	2011-04-05 15:53:14.021366	2011-04-05 15:53:14.021366
18	Lake	Acres		sd2.jpg\n	2011-04-05 15:53:14.024246	2011-04-05 15:53:14.024246
19	Redstone	Ridge		sd3.jpg\n	2011-04-05 15:53:14.027878	2011-04-05 15:53:14.027878
20	Coyote	Run		sd4.jpg\n	2011-04-05 15:53:14.031358	2011-04-05 15:53:14.031358
21	Buffalo	Village		sd8.jpg\n	2011-04-05 15:53:14.038611	2011-04-05 15:53:14.038611
22	Falcon	Greens		sd5.jpg\n	2011-04-05 15:53:14.042045	2011-04-05 15:53:14.042045
23	Heritage	Heights		sd8.jpg\n	2011-04-05 15:53:14.045984	2011-04-05 15:53:14.045984
\.


--
-- Name: subdivisions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: api
--

SELECT pg_catalog.setval('subdivisions_id_seq', 1, false);


--
-- Name: melt_bananas_pkey; Type: CONSTRAINT; Schema: public; Owner: api; Tablespace: 
--

ALTER TABLE ONLY melt_bananas
    ADD CONSTRAINT melt_bananas_pkey PRIMARY KEY (id);


--
-- Name: minutemen_pkey; Type: CONSTRAINT; Schema: public; Owner: api; Tablespace: 
--

ALTER TABLE ONLY minutemen
    ADD CONSTRAINT minutemen_pkey PRIMARY KEY (id);


--
-- Name: subdivisions_pkey; Type: CONSTRAINT; Schema: public; Owner: api; Tablespace: 
--

ALTER TABLE ONLY subdivisions
    ADD CONSTRAINT subdivisions_pkey PRIMARY KEY (id);


--
-- Name: unique_id; Type: CONSTRAINT; Schema: public; Owner: api; Tablespace: 
--

ALTER TABLE ONLY melt_bananas
    ADD CONSTRAINT unique_id UNIQUE (id);


--
-- Name: public; Type: ACL; Schema: -; Owner: r622233
--

REVOKE ALL ON SCHEMA public FROM PUBLIC;
REVOKE ALL ON SCHEMA public FROM r622233;
GRANT ALL ON SCHEMA public TO r622233;
GRANT ALL ON SCHEMA public TO PUBLIC;


--
-- PostgreSQL database dump complete
--

